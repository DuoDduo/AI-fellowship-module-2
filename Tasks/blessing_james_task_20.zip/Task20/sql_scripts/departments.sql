INSERT INTO Departments (dept_id, department_name, manager_name)
VALUES
  (1, 'Administration', 'Jennifer Walsh'),
  (2, 'Children & Youth Services', 'Rebecca Foster'),
  (3, 'Reference & Research', 'Thomas Anderson'),
  (4, 'Circulation', 'Maria Gonzalez'),
  (5, 'Technical Services', 'Kevin O''Brien'),
  (6, 'Information Technology', 'Daniel Rodriguez'),
  (7, 'Security & Facilities', 'James Brown'),
  (8, 'Community Programs', 'Linda Garcia');

SELECT * FROM Departments